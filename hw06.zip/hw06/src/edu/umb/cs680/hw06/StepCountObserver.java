package edu.umb.cs680.hw06;

public interface StepCountObserver {

    public abstract void updateStepCount(StepCount event);
    
}
