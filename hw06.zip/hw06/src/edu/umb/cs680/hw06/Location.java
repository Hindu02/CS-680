package edu.umb.cs680.hw06;

public class Location {

    int latitude, longitude;
    
    public Location(int latitude, int longitude) {
        this.latitude = latitude;
        this.longitude = longitude;
    }
    
}
