package edu.umb.cs680.hw06;

public class StepCount {

    int step;
    
    public StepCount(int step) {
        this.step = step;
    }
    
}
