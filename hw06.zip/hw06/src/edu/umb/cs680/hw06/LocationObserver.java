package edu.umb.cs680.hw06;

public interface LocationObserver {

    public abstract void updateLocation(Location event);
       
} 
